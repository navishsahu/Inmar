﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InmarWebApis.Models
{
    public class Offer
    {
        public string OfferName { get; }
        public List<Product> Products { get; }
        Offer(string offerName, List<Product> products)
        {
            offerName = OfferName;
            products = Products;
        }
    }
}