﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InmarLogicalSkill
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting Fizz Buzz Program");
            for (int i = 1; i <= 100; i++)
            {
                if(i % 3 == 0 && i % 5 == 0)
                {
                    Console.WriteLine("FizzBuzz");
                }
                else if(i % 3 == 0)
                {
                    Console.WriteLine("Fizz");
                }
                else if(i % 5 == 0)
                {
                    Console.WriteLine("Buzz");
                }
                else
                {
                    Console.WriteLine(i);
                }
            }
            Console.WriteLine("Ending Fizz Buzz Program");
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
            Console.WriteLine("Starting String Reverse Program");
            string str = "abcdef", reverse = String.Empty;
            int length = str.Length - 1;
            while(length >= 0)
            {
                reverse = reverse + str[length];
                length--;
            }
            Console.WriteLine("{0} is reveserd to {1}", str, reverse);
            Console.WriteLine("Ending String Reverse Program");
            Console.ReadLine();
        }
    }
}
