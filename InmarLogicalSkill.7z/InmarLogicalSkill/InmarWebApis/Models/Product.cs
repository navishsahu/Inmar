﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InmarWebApis.Models
{
    public class Product
    {
        public string ProductName { get; }
        public decimal Price { get; }
        public string Description { get; }
        Product(string prodName, decimal price, string desc)
        {
            prodName = ProductName;
            price = Price;
            desc = Description;
        }
    }
}