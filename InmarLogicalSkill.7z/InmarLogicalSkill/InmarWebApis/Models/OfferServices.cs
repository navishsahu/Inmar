﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InmarWebApis.Models
{
    public class OfferServices
    {
        private List<Product> Inventory { get; set; }

        private IEnumerable<Product> CreateProducts()
        {
            IList<Product> products = new List<Product>
            {

            };
            return products;
        }
            
            
    }
}